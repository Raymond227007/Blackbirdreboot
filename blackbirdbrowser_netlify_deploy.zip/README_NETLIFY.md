# Netlify Drag-and-Drop Deploy — Blackbirdbrowser Reboot

This folder is ready for **instant deploy** on Netlify.

## Steps
1. Go to https://app.netlify.com/drop
2. Drag this entire **unzipped folder** onto the page.
3. Netlify will upload and give you a live URL you can share.

## Notes
- This demo uses React + Tailwind via **CDN** and compiles JSX in the browser with **Babel** (fine for previews).
- For production apps, consider a proper build (Next.js or Vite) and hooking the Download/Shop buttons to real pages.

## Contact
- Email: info@blackbirdreboot.com
